#!/bin/bash

# Calculates token and type coverage for the Foma FST Yupik grammar
# Directory structure required by script is as follows:
#
# +-- analyzer_output
# |   +-- get_fst_coverage-percentage.sh
# |   +-- $DIR (Name of $DIR gives the date on which the FST was run)
#              (Contains the *.out and *.errors files produced by running the analyzer via run-morph.sh)
# |       +-- lore_volume1
# |       +-- lore_volume2
# |       +-- etc.
# |   +-- txts
# |       +-- original_txts (Contains the original, digitized source text)
# |           +-- lore_volume1
# |           +-- lore_volume2
# |           +-- etc.
# |       +-- txts_ess-only (Contains the digitized source text, preprocessed to remove foreign borrowings)
# |           +-- lore_volume1
# |           +-- lore_volume2
# |           +-- etc.


# ---------------#
#   BEGIN CODE   #
# ---------------#

# TODO: Toggle *.in files as needed, that is, whether the foreign borrowings should be included or not
# TODO: Change directory path here
DIR="./all_2018-08-17"


echo -e "-------------------------"
echo -e "TOKEN Coverage Percentage"
echo -e "-------------------------"

for d in $DIR/*; do
	curr_dir="$(basename "$d")"

	# IN_FILES="./txts/original_txts/$curr_dir"		# Original texts with foreign borrowings included 
	IN_FILES="./txts/txts_ess-only/$curr_dir.ess"	# Preprocessed texts with foreign borrowings removed

	ERR_FILES="$DIR/$curr_dir"

	sum_errors=$(find "$ERR_FILES"/ -name '*.errors' -exec cat {} \; | sed 's/.*: //' | cut -f1 | sort | wc -l) # Counts all errors

	total=$(cat "$IN_FILES"/*.in | awk '{ for(i=1; i <= NF; i++) {print $i } }' | tr -d ',;:()[]"!?.=/[:digit:]-' | tr '[:upper:]' '[:lower:]' | sort | wc -w)

	let sum_correct=$( echo $((total - sum_errors)) )
	echo -ne "$curr_dir:\t"
	awk -v sum_errors="$sum_errors" -v total="$total" 'BEGIN{printf "%0.2f\n", (total-sum_errors)/total * 100}'
done


echo -e "\n"


echo -e "-------------------------"
echo -e "TYPE Coverage Percentage"
echo -e "-------------------------"

for d in $DIR/*; do
	curr_dir="$(basename "$d")"

	# IN_FILES="./txts/original_txts/$curr_dir"		# Original texts with foreign borrowings included 
	IN_FILES="./txts/txts_ess-only/$curr_dir.ess"	# Preprocessed texts with foreign borrowings removed

	ERR_FILES="$DIR/$curr_dir"

	sum_errors=$(find "$ERR_FILES"/ -name '*.errors' -exec cat {} \; | sed 's/.*: //' | cut -f1 | sort | uniq | wc -l)	# Counts unique errors

	total=$(cat "$IN_FILES"/*.in | awk '{ for(i=1; i <= NF; i++) {print $i } }' | tr -d ',;:()[]"!?.=/[:digit:]-' | tr '[:upper:]' '[:lower:]' | sort | uniq | wc -w)

	let sum_correct=$( echo $((total - sum_errors)) )
	echo -ne "$curr_dir:\t"
	awk -v sum_errors="$sum_errors" -v total="$total" 'BEGIN{printf "%0.2f\n", (total-sum_errors)/total * 100}'
done


########
