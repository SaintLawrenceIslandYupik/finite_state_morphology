#!/bin/bash

FILE='volume1.part1.text1.ess.txt.out'
OUTPUT=${FILE%.ess.txt.out}.multi-analyses.csv

# Identifies words with over the preferred maximum number of analyses
overMax=$(grep $'\t' $FILE | sort | uniq | cut -f1 | sort | uniq -c | gawk '$1>10{print $2}')
readarray -t overMaxArray <<< "$overMax"
# printf '%s\n' "${overMaxArray[@]}"

# Identifies words with at least two analyses
overTwo=$(grep $'\t' $FILE | sort | uniq | cut -f1 | sort | uniq -c | gawk '$1>1{print $2}')
readarray -t overTwoArray <<< "$overTwo"

# Creates an array of words with 2 - MAX number of analyses
# Removes words with >MAX number of analyses from the array of words with >2 analyses
for duplicate in "${overMaxArray[@]}"; do
	for i in "${!overTwoArray[@]}"; do
		if [[ ${overTwoArray[i]} == "${duplicate}" ]]; then
			unset overTwoArray[i]
		fi
	done
done
# printf '%s\n' "${overTwoArray[@]}"

#declare -a twoToMaxArray
#for i in ${overTwoArray[@]}; do
#	if [[ ${overTwoArray[i]} ]]; then
#		twoToMaxArray+=(${overTwoArray[i]})
#	fi
#done

echo -e "Word,Analysis 1,Analysis 2,Analysis 3,Analysis 4,Analysis 5,Analysis 6,Analysis 7,Analysis 8,Analysis 9,Analysis 10" > $OUTPUT

# Writes words with 2 - MAX number of analyses to the output .csv file
for word in ${overTwoArray[@]}; do
	analyses=$(grep $'\t' $FILE | sort | uniq | grep -w $word | cut -f2)
	readarray -t analysesArray <<< "$analyses"
	# printf '%s\n' "${analysesArray[@]}"

	analysesWithComma=""
	for analysis in ${analysesArray[@]}; do
		analysesWithComma="$analysesWithComma,$analysis"
	done

    echo -e $word$analysesWithComma
done >> $OUTPUT

# Writes words with >MAX number of analyses to the output .csv file
for word in ${overMaxArray[@]}; do
	echo -e $word,
done >> $OUTPUT
