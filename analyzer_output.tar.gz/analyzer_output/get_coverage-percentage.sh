#!/bin/bash

DIR="./all_2018-06-18/*"

for d in $DIR; do

	curr_dir=$(basename $d)

	IN_FILES="./txts/$curr_dir"
	ERR_FILES="./all_2018-06-18/$curr_dir"

	sum_errors=$(find "$ERR_FILES"/*.errors -type f | xargs wc -l | tail -1 | awk '{print $1}') 
	total=$(find "$IN_FILES"/*.in -type f | xargs wc -w | tail -1 | awk '{print $1}')

	let sum_correct=$( echo $((total - sum_errors)) )

	echo -ne "$curr_dir:\t"
	awk -v sum_errors="$sum_errors" -v total="$total" 'BEGIN{printf "%0.2f\n", (total-sum_errors)/total * 100}'
done
