#!/bin/bash

# TODO: Change this variable, depending on which text is being analyzed for unsuccessful parses
TXT="ungipaghaghlanga"

IN_FILES="../txts/$TXT/"
WORD_FILE="./$TXT/unanalyzed-words.txt" # TODO: May need to change filenames if re-running script

UNANALYZED_WORDS=${WORD_FILE%.txt}.csv # Output file

# Unanalyzed words that could not be identified in the original texts
declare -a manual_check

# Converts filename to story title 
declare -A stories
stories["volume1.part1.text1.ess.txt.in"]="'Sivuqam Ungipaa', LORE VOL.1"
stories["volume1.part1.text2.ess.txt.in"]="'Sivuqam Kiyaghtaallgha Ayumiq', LORE VOL.1"
stories["volume1.part1.text3.ess.txt.in"]="'Aqellqaghniiq', LORE VOL.1"
stories["volume1.part1.text4.ess.txt.in"]="'Sivuqam Kiyaghtaallgha 1930-Ni', LORE VOL.1"
stories["volume1.part2.text1.ess.txt.in"]="'Ayumiim Mangteghasqwaaghillu Mangteghapigillu', LORE VOL.1"
stories["volume1.part2.text2.ess.txt.in"]="'Neqemllu Kagpallgha', LORE VOL.1"
stories["volume1.part2.text3.ess.txt.in"]="'Aatkam Kakillgha, Atuqellgha Neghighluku', LORE VOL.1"
stories["volume1.part2.text4.ess.txt.in"]="'Neghighluku Unangniileq Maani Sivuqami', LORE VOL.1"
stories["volume1.part2.text5.ess.txt.in"]="'Nateng Angyapigem Uliimallghi', LORE VOL.1"
stories["volume1.part2.text6.ess.txt.in"]="'Sanqutet Ayveghniighmun', LORE VOL.1"
stories["volume1.part2.text7.ess.txt.in"]="'Sanqutngi Aghveghniighem', LORE VOL.1"
stories["volume1.part3.text1.ess.txt.in"]="'Ayumiim Eghqwaallghallu, Eghqwaaghusaallu', LORE VOL.1"
stories["volume1.part3.text2.ess.txt.in"]="'Eghqwaallqem Yataaghqelleq', LORE VOL.1"
stories["volume1.part3.text3.ess.txt.in"]="'Ivaghulluk Ilagaat', LORE VOL.1"
stories["volume1.part3.text4.ess.txt.in"]="'Aghveghniighem Pillghi', LORE VOL.1"
stories["volume1.part3.text5.ess.txt.in"]="'Aghveghemllu Uyvasaghqellgha', LORE VOL.1"
stories["volume1.part3.text6.ess.txt.in"]="'Qamestam aavgullghi Uyvasaghqellghillu', LORE VOL.1"
stories["volume1.part3.text7.ess.txt.in"]="'Aghqesaghtum Pinga', LORE VOL.1"

stories["volume2.part1.text1.ess.txt.in"]="'Sivuliq', LORE VOL.2"
stories["volume2.part1.text2.ess.txt.in"]="'Ivaghima Aghnaq Iknaqelghii', LORE VOL.2"
stories["volume2.part1.text3.ess.txt.in"]="'Sivuliighaput', LORE VOL.2"
stories["volume2.part1.text4.ess.txt.in"]="'Aghveghniighyuwhaallghat Sivungaghmiit', LORE VOL.2"
stories["volume2.part2.text1.ess.txt.in"]="'Piinlillgha Quyngim', LORE VOL.2"
stories["volume2.part2.text2.ess.txt.in"]="'Quyngighqwaalqa', LORE VOL.2"
stories["volume2.part2.text3.ess.txt.in"]="'Quyngim Atuqellgha', LORE VOL.2"
stories["volume2.part3.text1.ess.txt.in"]="'Iikutat', LORE VOL.2"
stories["volume2.part3.text2.ess.txt.in"]="'Aghnaghaallemneng Neqamikelqa', LORE VOL.2"
stories["volume2.part3.text3.ess.txt.in"]="'Kaavam Anglinaqellgha', LORE VOL.2"
stories["volume2.part3.text4.ess.txt.in"]="'Vupiget Neqniillghat', LORE VOL.2"
stories["volume2.part3.text5.ess.txt.in"]="'Qagaqum Pangeghtelleghqek', LORE VOL.2"
stories["volume2.part4.text1.ess.txt.in"]="'Singaaweteghllagem Ungipamsuwa', LORE VOL.2"
stories["volume2.part4.text2.ess.txt.in"]="'Nanevgaghhaam Gugiingem Kasivagutellgha Nanumeng', LORE VOL.2"
stories["volume2.part4.text3.ess.txt.in"]="'Qilagem Taghnughhaa', LORE VOL.2"
stories["volume2.part4.text4.ess.txt.in"]="'Naghuyangughtekaq', LORE VOL.2"
stories["volume2.part4.text5.ess.txt.in"]="'Naghuyangughtekaq', LORE VOL.2"
stories["volume2.part4.text6.ess.txt.in"]="'Yuuk Neqengyuqaq Ungipaghaq', LORE VOL.2"

stories["volume3.part1.text1.ess.txt.in"]="'Pugughileq', LORE VOL.3"
stories["volume3.part1.text2.ess.txt.in"]="'Anglinaqelqa Pugughileghmi', LORE VOL.3"
stories["volume3.part1.text3.ess.txt.in"]="'Pugughileq', LORE VOL.3"
stories["volume3.part1.text4.ess.txt.in"]="'Anglinaqngulunga', LORE VOL.3"
stories["volume3.part1.text5.ess.txt.in"]="'Pugughilghem Paneghaatellgha', LORE VOL.3"
stories["volume3.part1.text6.ess.txt.in"]="'Neqamikelqa Pugughileghmelluta', LORE VOL.3"
stories["volume3.part2.text1.ess.txt.in"]="'Kukulegmiit', LORE VOL.3"
stories["volume3.part2.text2.ess.txt.in"]="'Anglinghhaalunga', LORE VOL.3"
stories["volume3.part2.text3.ess.txt.in"]="'Kiyaghtaalqa, Igleghalqallu', LORE VOL.3"
stories["volume3.part2.text4.ess.txt.in"]="'Yupigem Ugpellgha', LORE VOL.3"
stories["volume3.part2.text5.ess.txt.in"]="'Meregtemeng Tumet Sivuqamun', LORE VOL.3"
stories["volume3.part2.text6.ess.txt.in"]="'Taghnughhaghmun Atighilleq Sivuqami', LORE VOL.3"
stories["volume3.part3.text1.ess.txt.in"]="'Ayngaghlingaawetenkuk, Qilakaghiilaankuk', LORE VOL.3"
stories["volume3.part3.text2.ess.txt.in"]="'Aliineghsiisiq Yagesgu', LORE VOL.3"
stories["volume3.part3.text3.ess.txt.in"]="'Iiyaghhiinalek', LORE VOL.3"
stories["volume3.part3.text4.ess.txt.in"]="'Meteghllugllagenkuk Anipaghllagenkuk', LORE VOL.3"
stories["volume3.part3.text5.ess.txt.in"]="'Ivisangiighhaq', LORE VOL.3"
stories["volume3.part3.text6.ess.txt.in"]="'Sikughaaghenkut, Kaviighhaankut, Meteghllugllagenkut', LORE VOL.3"

stories["00_TblCon.ess.txt.in"]="'Table of Contents', PRIMER LVL.1"
stories["01_Sivuqaq.ess.txt.in"]="'Why The Island Was Named Sivuqaq', PRIMER LVL.1"
stories["02_ChewingGum.ess.txt.in  "]="'The Mysterious Eskimo Chewing Gum', PRIMER LVL.1"
stories["02_ChewingGum-Note.ess.txt.in"]="'The Mysterious Eskimo Chewing Gum - Note', PRIMER LVL.1"
stories["04_RavenWolf.ess.txt.in"]="'Wolf Teases Cousin Raven', PRIMER LVL.1"
stories["05_Tufword1.ess.txt.in"]="'Word Review 1', PRIMER LVL.1"
stories["06_Kiiluq.ess.txt.in"]="'Kiiluq's Burden', PRIMER LVL.1"
stories["08_Christmas.ess.txt.in"]="'Poorest Richest Christmas', PRIMER LVL.1"
stories["09_Tufword2.ess.txt.in"]="'Word Review 2', PRIMER LVL.1"
stories["10_UglyBoy.ess.txt.in"]="'Ugly Boy Finds a Wife', PRIMER LVL.1"
stories["12_Iistumii-Appendix.ess.txt.in"]="'A Lesson for Iistumii', PRIMER LVL.1"
stories["12_Iistumii.ess.txt.in"]="'A Lesson for Iistumii - Appendix', PRIMER LVL.1"
stories["13_Tufword3.ess.txt.in"]="'Word Review 3', PRIMER LVL.1"
stories["14_Tooth.ess.txt.in"]="'Ouch! My Tooth!', PRIMER LVL.1"
stories["16_Kaspik.ess.txt.in"]="'Kaspik's Close Call', PRIMER LVL.1"
stories["18_Squirrel.ess.txt.in"]="'Squirrel Outwits Old Man Raven', PRIMER LVL.1"
stories["19_Glossary.ess.txt.in"]="'Glossary', PRIMER LVL.1"
stories["IceTest.ess.txt.in "]="'Ice Test', PRIMER LVL.1"
stories["Idioms.ess.txt.in"]="'Idioms', PRIMER LVL.1"

stories["10Y.txt.in"]="'Two Wise Reindeer', PRIMER LVL.2"
stories["11Y.txt.in "]="'The Man Who Like to Sleep', PRIMER LVL.2"
stories["12Y.txt.in "]="'Kayaker and Two Women', PRIMER LVL.2"
stories["13Y.txt.in "]="'Little Girl Lost in the Fog', PRIMER LVL.2"
stories["1Y.txt.in"]="'Battle for the Mountain Outcrop', PRIMER LVL.2"
stories["2Y.txt.in"]="'A Little Boy Kidnapped to a Land of Darkness', PRIMER LVL.2"
stories["3Y.txt.in"]="'A Thoughtful Man Rewarded', PRIMER LVL.2"
stories["4Y-T.txt.in"]="'Tides and Currents of St. Lawrence Island', PRIMER LVL.2"
stories["4Y.txt.in"]="'The Little Servant Crab', PRIMER LVL.2"
stories["5Y-I.txt.in"]="'Sulpik - Idiom', PRIMER LVL.2"
stories["5Y.txt.in"]="'Sulpik', PRIMER LVL.2"
stories["6Y-I.txt.in"]="'Sulpik Meets A Monster - Idiom', PRIMER LVL.2"
stories["6Y.txt.in"]="'Sulpik Meets A Monster', PRIMER LVL.2"
stories["7Y-I.txt.in"]="'Sulpik's Good Luck - Idiom', PRIMER LVL.2"
stories["7Y.txt.in"]="'Sulpik's Good Luck', PRIMER LVL.2"
stories["8Y-I.txt.in"]="'The Forbidden Mountain - Idiom', PRIMER LVL.2"
stories["8Y.txt.in"]="'The Forbidden Mountain', PRIMER LVL.2"
stories["9Y-I.txt.in"]="'Puppy In The Wild - Idiom', PRIMER LVL.2"
stories["9Y.txt.in"]="'Puppy In The Wild', PRIMER LVL.2"
stories["GLOSS-Y.txt.in"]="'Glossary', PRIMER LVL.2"

stories["BIRD1-Leghlleq-Y.txt.in"]="'Leghlleq', PRIMER LVL.3"
stories["BIRD2_Alpa-Y.txt.in"]="'Alpa', PRIMER LVL.3"
stories["BIRD3_Pagrugwaq-Y.txt.in"]="'Pagrugwaq', PRIMER LVL.3"
stories["BIRD4_Tekeyiighaq-Y.txt.in"]="'Tekeyiighaq', PRIMER LVL.3"
stories["CAMP_Nunaamnni-Y.txt.in"]="'Nunaamnni Teghigniqelleghput', PRIMER LVL.3"
stories["CASES_Suflugwamun.txt.in"]="'Suflugwamun Qantangllaqlu Akmagtangllaq', PRIMER LVL.3"
stories["DOG_Qikmim-Y.txt.in"]="'Qikmim Ilakumtaalleghpigaa', PRIMER LVL.3"
stories["FATHER_Atam-Y.txt.in"]="'Atam Liilightullgha Ipanguftuq', PRIMER LVL.3"
stories["GIANT_Mayeraaghpagllak.txt.in"]="'Mayeraaghpagllak', PRIMER LVL.3"
stories["GLOSS-Y.txt.in"]="'Glossary', PRIMER LVL.3"
stories["HOMON1-Y.txt.in"]="'Yupigem Homonym-ngi 1', PRIMER LVL.3"
stories["HOMON2-Y.txt.in"]="'Yupigem Homonym-ngi 2', PRIMER LVL.3"
stories["HOMON3-Y.txt.in"]="'Yupigem Homonym-ngi 3', PRIMER LVL.3"
stories["HOMON4-Y.txt.in"]="'Yupigem Homonym-ngi 4', PRIMER LVL.3"
stories["ICETEST_Tugweq-Y.txt.in"]="'Tugweq / Uunghaq', PRIMER LVL.3"
stories["INSECTS_Tunusat-Y.txt.in"]="'Tunusat Kumagnun', PRIMER LVL.3"
stories["MOUNTAIN_Naayghaa-Y.txt.in"]="'Sivuqam Naayghaa', PRIMER LVL.3"
stories["MOUSE_Ilutuqaq.txt.in"]="'Ilutuqaq Afsengaaghaghhaq', PRIMER LVL.3"
stories["MUREGG_Manigi-Y.txt.in"]="'Alpam Manigi', PRIMER LVL.3"
stories["ORPHAN_Yaywaali-Y.txt.in "]="'Yaywaali Nulightulghii Nanumeng', PRIMER LVL.3"
stories["PART1-Y.txt.in"]="'Part 1', PRIMER LVL.3"
stories["PART2-Y.txt.in"]="'Part 2', PRIMER LVL.3"
stories["PART3-Y.txt.in"]="'Part 3', PRIMER LVL.3"
stories["REINDEER_Aghulisigatat-Y.txt.in"]="'Sangameng Quyngit Aghulisigatat', PRIMER LVL.3"
stories["ROCKS_Uyghagi-Y.txt.in"]="'Sivuqam Uyghagi', PRIMER LVL.3"
stories["SCHOOL_Igaghvigraaghaq-Y.txt.in"]="'Igaghvigraaghaq', PRIMER LVL.3"
stories["SEASONS_Uksuq-Upengaq-Kiik-Uksaaq-Y.txt.in"]="'Uksuq, Upenghaq, Kiik, Uksaaq', PRIMER LVL.3"
stories["SHARON-Y.txt.in"]="'Sharon’s Story', PRIMER LVL.3"
stories["SHIRT_Kavilnguuq-Y.txt.in"]="'Kavilnguuk Qiipaghaak', PRIMER LVL.3"
stories["STOVE_Egllungllaq-Y.txt.in"]="'Egllungllaq Naghaaghutmeng', PRIMER LVL.3"
stories["SULPIK1-Y.txt.in"]="'Sulpik Naapleghhii Kaviighmeng', PRIMER LVL.3"
stories["SULPIK2-Y.txt.in"]="'Sulpik Iilqayugwigalnguq', PRIMER LVL.3"
stories["SULPIK3-Y.txt.in"]="'Sulpik Nulughyalghii', PRIMER LVL.3"

stories["ungi.part0-introduction.ess.txt.in"]="'Piinlilleq', UNGIPAGHAGHLANGA"
stories["ungi.part1-ayveghlaq.text1.ess.txt.in"]="'Ukamangaan', UNGIPAGHAGHLANGA"
stories["ungi.part1-ayveghlaq.text2.ess.txt.in"]="'Ungipaghaan Ukiivagmiit', UNGIPAGHAGHLANGA"
stories["ungi.part1-ayveghlaq.text3.ess.txt.in"]="'Yaywaalingiighhaak', UNGIPAGHAGHLANGA"
stories["ungi.part1-ayveghlaq.text4.ess.txt.in"]="'Aghhaghhangaawraq', UNGIPAGHAGHLANGA"
stories["ungi.part1-ayveghlaq.text5.ess.txt.in"]="'Ungipaghaan Qigighhmiik', UNGIPAGHAGHLANGA"
stories["ungi.part1-ayveghlaq.text6.ess.txt.in"]="'Ungipaghaan Yaqellengetaq', UNGIPAGHAGHLANGA"
stories["ungi.part1-ayveghlaq.text7.ess.txt.in"]="'Vuvallanga Ayapeghyugem', UNGIPAGHAGHLANGA"
stories["ungi.part1-ayveghlaq.text8.ess.txt.in"]="'Tungtughllak Enkaam Kavengenghaghhaq', UNGIPAGHAGHLANGA"
stories["ungi.part2-tagikaq.text10.ess.txt.in"]="'Uzivikaq Paallghunkuk Ama Qetngalleghyankuk', UNGIPAGHAGHLANGA"
stories["ungi.part2-tagikaq.text11.ess.txt.in"]="'Aqanga', UNGIPAGHAGHLANGA"
stories["ungi.part2-tagikaq.text12.ess.txt.in"]="'Iikusimaak', UNGIPAGHAGHLANGA"
stories["ungi.part2-tagikaq.text13.ess.txt.in"]="'Aymangaawen', UNGIPAGHAGHLANGA"
stories["ungi.part2-tagikaq.text14.ess.txt.in"]="'Qayaqsighvik', UNGIPAGHAGHLANGA"
stories["ungi.part2-tagikaq.text15.ess.txt.in"]="'Kayusiqaa Aghnaq', UNGIPAGHAGHLANGA"
stories["ungi.part2-tagikaq.text16.ess.txt.in"]="'Ighnegha Kiighwyaaghtekaq', UNGIPAGHAGHLANGA"
stories["ungi.part2-tagikaq.text17.ess.txt.in"]="'Kiighwyaq', UNGIPAGHAGHLANGA"
stories["ungi.part2-tagikaq.text18.ess.txt.in"]="'Vuvallanga', UNGIPAGHAGHLANGA"
stories["ungi.part2-tagikaq.text19.ess.txt.in"]="'Nulightuqaq Ayuqlit Aghniitneng', UNGIPAGHAGHLANGA"
stories["ungi.part2-tagikaq.text20.ess.txt.in"]="'Kiyaghtaaq Quurkeli Meteghlluk', UNGIPAGHAGHLANGA"
stories["ungi.part2-tagikaq.text9.ess.txt.in"]="'Afsengaghhaq', UNGIPAGHAGHLANGA"
stories["ungi.part3-asuya.text21.ess.txt.in"]="'Mayeraaghpak', UNGIPAGHAGHLANGA"
stories["ungi.part3-asuya.text22.ess.txt.in"]="'Ngelqat', UNGIPAGHAGHLANGA"
stories["ungi.part4-alghalek.text23.ess.txt.in"]="'Unangyiilnguq Enkaam Nanuq', UNGIPAGHAGHLANGA"
stories["ungi.part4-alghalek.text24.ess.txt.in"]="'Napaqutaghhmii', UNGIPAGHAGHLANGA"
stories["ungi.part4-alghalek.text25.ess.txt.in"]="'Qatelghiinkuk', UNGIPAGHAGHLANGA"
stories["ungi.part4-alghalek.text26.ess.txt.in"]="'Egeghaghmii', UNGIPAGHAGHLANGA"
stories["ungi.part4-alghalek.text27.ess.txt.in"]="'Enkaam Quyillek', UNGIPAGHAGHLANGA"
stories["ungi.part4-alghalek.text28.ess.txt.in"]="'Yuuk Enkaam Qateghyiighaghhaq', UNGIPAGHAGHLANGA"
stories["ungi.part4-alghalek.text29.ess.txt.in"]="'Aghnaghaghhaq Angayuqiilnguq', UNGIPAGHAGHLANGA"
stories["ungi.part4-alghalek.text30.ess.txt.in"]="'Qatelghiinkuk Amaankuk', UNGIPAGHAGHLANGA"
stories["ungi.part4-alghalek.text31.ess.txt.in"]="'Aghnaghaq Uyughalek', UNGIPAGHAGHLANGA"
stories["ungi.part4-alghalek.text32.ess.txt.in"]="'Aghnaghaq Ulghaaghughtekaq', UNGIPAGHAGHLANGA"
stories["ungi.part5-nanughhaq.text33.ess.txt.in"]="'Ilagaan', UNGIPAGHAGHLANGA"
stories["ungi.part5-nanughhaq.text34.ess.txt.in"]="'Talaka', UNGIPAGHAGHLANGA"
stories["ungi.part6-wiri.text35.ess.txt.in"]="'Pista', UNGIPAGHAGHLANGA"


#----------------#
#   BEGIN CODE   #
#----------------#

while read word; do

	result=$(grep -r -m 1 "$word" $IN_FILES)

	if [ -z "$result" ]; then	
		# Capitalize 'word' and search
		result=$(grep -r -m 1 "${word^}" $IN_FILES)

		if [ -z "$result" ]; then
			manual_check+=($word)
			continue
		fi
	fi

	source_text=$(echo $result | cut -d ":" -f1 | rev | cut -d "/" -f1 | rev)

	sent=$(echo $result | cut -d ":" -f2 | cut -d "." -f1)

	echo -e "$word,\"$sent.\",\"${stories[$source_text]}\""
done < $WORD_FILE > $UNANALYZED_WORDS

printf '%s\n' "CHECK MANUALLY:" "${manual_check[@]}"
